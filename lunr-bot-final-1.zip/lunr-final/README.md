# 🤖 LUNR BOT v4.0.0

> WhatsApp Multi-Device Bot powered by **real Anthropic Claude AI**  
> Built on [Baileys](https://github.com/WhiskeySockets/Baileys) • Node.js 18+

---

## ✨ What's New in v4.0.0

| Feature | v3 (original) | v4 Pro |
|---|---|---|
| `.gpt` / `.gemini` | 3rd-party scrapers (often broken) | ✅ Real Anthropic Claude API |
| `.llama` | ❌ Not available | ✅ Claude with LLaMA persona |
| `.mistral` | ❌ Not available | ✅ Claude with Mistral persona |
| `.imagine` / `.flux` | Shizo API (unreliable) | ✅ Pollinations AI (free, stable) |
| `.sora` | Single API (often fails) | ✅ Multi-API fallback |
| Chatbot mode | Scraper-based | ✅ Real Claude API |
| Conversation memory | ❌ None | ✅ Per-user (30 min) |
| New AI commands | ❌ | ✅ 20+ new commands |

---

## 🚀 Quick Setup

### 1. Clone / extract this project
```bash
# If you have git
git clone <your-repo>
cd lunr-bot

# OR just extract the zip
```

### 2. Install dependencies
```bash
npm install --legacy-peer-deps
```

### 3. Set your Anthropic API key

Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```

Edit `.env`:
```
ANTHROPIC_API_KEY=sk-ant-your-key-here
OWNER_NUMBER=919876543210
```

**Get your free API key at:** https://console.anthropic.com

> The free tier gives you plenty of credits to run the bot.

### 4. Set your phone number in `settings.js`
```js
ownerNumber: '919876543210',  // Your number without +
```

### 5. Start the bot
```bash
npm start
```

Scan the QR code with WhatsApp → Linked Devices → Link a Device.

---

## 🧠 AI Commands Reference

All AI commands use real Anthropic Claude — they actually work!

### Text AI
| Command | Description |
|---|---|
| `.gpt <question>` | Ask anything (GPT persona) |
| `.claude <question>` | Ask Claude directly |
| `.ai <question>` | General AI assistant |
| `.gemini <question>` | Ask with Gemini persona |
| `.llama <question>` | Ask with LLaMA persona |
| `.mistral <question>` | Ask with Mistral persona |
| `.ask <question>` | Quick Q&A |
| `.chat <message>` | Conversational mode |
| `.aiforget` | Clear your conversation memory |

> 💡 All text AI commands **remember your last 5 turns** (30 min). Ask follow-up questions!

### Image Generation (FREE — no extra API key)
| Command | Style |
|---|---|
| `.imagine <prompt>` | Photorealistic |
| `.flux <prompt>` | Cinematic/dramatic |
| `.dalle <prompt>` | Digital art |
| `.art <prompt>` | Fine art |
| `.draw <prompt>` | Detailed sketch |
| `.paint <prompt>` | Oil painting |

### Video Generation
| Command | Description |
|---|---|
| `.sora <prompt>` | AI text-to-video |
| `.videogen <prompt>` | Same as .sora |

### Creative AI
| Command | Description |
|---|---|
| `.roast @user` | Funny roast |
| `.rizz @user` | Smooth rizz line |
| `.poem <topic>` | Beautiful poem |
| `.story <topic>` | Short story with twist |
| `.haiku <topic>` | 5-7-5 haiku |
| `.caption <context>` | 3 Instagram captions |
| `.explain <concept>` | ELI5 explanation |
| `.code <task>` | Write code |
| `.debate <topic>` | Devil's advocate |
| `.recipe <dish>` | Cooking recipe |
| `.advice <problem>` | Wise advice |
| `.bio <description>` | Social media bio |
| `.pickup` | Pickup line |
| `.motivate <context>` | Motivational message |
| `.fact <topic>` | Fascinating fact |
| `.joke <type>` | AI-generated joke |
| `.quote <theme>` | Powerful quote |
| `.summarize` | Summarize replied message |
| `.translate <lang> <text>` | Translate text |

### Chatbot Mode (Auto-reply AI)
```
.chatbot on    → Enable AI auto-reply for this chat
.chatbot off   → Disable
.chatbot       → Check status
```

---

## 📁 Project Structure

```
lunr-bot/
├── index.js          ← WhatsApp connection (Baileys)
├── main.js           ← Message router + command dispatch
├── settings.js       ← Bot config (set your number here)
├── config.js         ← API endpoints
├── .env              ← Your API keys (create from .env.example)
├── commands/
│   ├── ai.js         ← 🆕 Real Claude AI (gpt/gemini/llama/etc)
│   ├── imagine.js    ← 🆕 AI image gen (Pollinations)
│   ├── sora.js       ← 🆕 AI video gen (multi-API)
│   ├── chatbot.js    ← 🆕 Real Claude chatbot mode
│   ├── creative.js   ← 🆕 20+ creative AI commands
│   ├── summarize.js  ← 🆕 AI summarization
│   ├── help.js       ← 🆕 Updated help menu
│   └── ...           ← All original commands preserved
├── lib/              ← Core utilities
└── data/             ← Bot state/settings JSON files
```

---

## 🔑 API Keys Summary

| Service | Key Needed | Where to Get |
|---|---|---|
| Anthropic Claude | ✅ Required | https://console.anthropic.com |
| Pollinations AI (images) | ❌ Free | No key needed |
| Video generation | ❌ Free | No key needed |
| All other commands | ❌ | Use existing free APIs |

---

## 🛠 Troubleshooting

**"Anthropic API error 401"**  
→ Your API key is wrong. Check `.env` and `settings.js`.

**".imagine returns error"**  
→ Pollinations might be slow. Try again in 30 seconds.

**".sora fails"**  
→ Video generation APIs are sometimes down. Try again later.

**Bot not responding to commands**  
→ Check `commandMode` in `settings.js` — set to `"public"` for everyone.

---

## 📜 License

MIT — Based on LUNR BOT-MD by Professor / Mr Unique Hacker. Rebranded as LUNR BOT.  
AI upgrades by LUNR BOT contributors.
