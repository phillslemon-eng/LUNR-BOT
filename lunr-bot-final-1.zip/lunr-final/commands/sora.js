/**
 * Video Generation Command
 * Handles: .sora  .video-ai  .videogen  .makevideo
 *
 * Uses okatsu API for text-to-video generation.
 * Falls back to a secondary API if primary fails.
 */

const https = require('https');
const http = require('http');
const { URL } = require('url');

const VIDEO_COMMANDS = new Set(['.sora', '.videogen', '.makevideo', '.vid-ai']);

async function getVideoUrl(prompt) {
  // Primary API
  const apis = [
    `https://okatsu-rolezapiiz.vercel.app/ai/txt2video?text=${encodeURIComponent(prompt)}`,
    `https://api.siputzx.my.id/api/ai/text2video?text=${encodeURIComponent(prompt)}`,
  ];

  for (const api of apis) {
    try {
      const res = await fetch(api, {
        timeout: 90000,
        headers: { 'user-agent': 'Mozilla/5.0 LUNR BOTPro/4.0' },
      });
      if (!res.ok) continue;
      const data = await res.json();
      const videoUrl =
        data?.videoUrl ||
        data?.result ||
        data?.data?.videoUrl ||
        data?.data?.url ||
        data?.url;
      if (videoUrl) return videoUrl;
    } catch {
      continue;
    }
  }
  throw new Error('All video generation APIs failed. Please try again later.');
}

async function soraCommand(sock, chatId, message) {
  try {
    const rawText =
      message.message?.conversation?.trim() ||
      message.message?.extendedTextMessage?.text?.trim() ||
      '';

    const parts = rawText.trim().split(/\s+/);
    const cmd = parts[0].toLowerCase();

    if (!VIDEO_COMMANDS.has(cmd)) return;

    const prompt = parts.slice(1).join(' ').trim();

    // Also accept quoted message as prompt
    const quotedText =
      message.message?.extendedTextMessage?.contextInfo?.quotedMessage?.conversation ||
      message.message?.extendedTextMessage?.contextInfo?.quotedMessage?.extendedTextMessage?.text ||
      '';

    const input = prompt || quotedText;

    if (!input) {
      return await sock.sendMessage(chatId, {
        text: `🎬 Provide a description for the video.\nExample: *${cmd}* anime girl with blue hair walking through a forest`,
      }, { quoted: message });
    }

    await sock.sendMessage(chatId, {
      react: { text: '🎬', key: message.key },
    });

    await sock.sendMessage(chatId, {
      text: '🎬 Generating video... This can take 30–90 seconds. Please wait.',
    }, { quoted: message });

    const videoUrl = await getVideoUrl(input);

    await sock.sendMessage(chatId, {
      video: { url: videoUrl },
      mimetype: 'video/mp4',
      caption: `🎬 *Prompt:* ${input}\n\n_Powered by AI Video Generation_`,
    }, { quoted: message });

    await sock.sendMessage(chatId, {
      react: { text: '✅', key: message.key },
    });

  } catch (err) {
    console.error('[SORA] Error:', err.message);
    await sock.sendMessage(chatId, {
      text: `❌ Video generation failed: ${err.message}`,
    }, { quoted: message });
  }
}

soraCommand.COMMANDS = VIDEO_COMMANDS;
module.exports = soraCommand;
