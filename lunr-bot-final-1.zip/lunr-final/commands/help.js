const settings = require('../settings');
const fs = require('fs');
const path = require('path');

async function helpCommand(sock, chatId, message) {
  const helpMessage = `
╔══════════════════════╗
   *🤖 ${settings.botName || 'LUNR BOT'}*  
   Version: *${settings.version || '4.0.0'}*
   by ${settings.botOwner || 'Professor'}
╚══════════════════════╝

*Available Commands:*

╔══════════════════════╗
🧠 *AI Commands (Real AI - Powered by Claude)*:
║ ➤ .gpt <question>
║ ➤ .claude <question>
║ ➤ .ai <question>
║ ➤ .gemini <question>
║ ➤ .llama <question>
║ ➤ .mistral <question>
║ ➤ .ask <question>
║ ➤ .chat <message>
║ ➤ .aiforget  ← clear your conversation
╚══════════════════════╝

╔══════════════════════╗
🎨 *AI Image Generation (FREE)*:
║ ➤ .imagine <prompt>
║ ➤ .flux <prompt>
║ ➤ .dalle <prompt>
║ ➤ .art <prompt>
║ ➤ .draw <prompt>
║ ➤ .paint <prompt>
╚══════════════════════╝

╔══════════════════════╗
🎨 *Premium Image Generation*:
║ ➤ .lunr <prompt>    (OpenAI DALL-E 3)
║ ➤ .lunrv2 <prompt>  (Google Imagen 3)
╚══════════════════════╝

╔══════════════════════╗
🎬 *AI Video Generation*:
║ ➤ .veo <prompt>        (Google Veo 2)
║ ➤ .sora <prompt>       (Free Sora)
║ ➤ .videogen <prompt>
╚══════════════════════╝

╔══════════════════════╗
📥 *Video Downloader*:
║ ➤ .dl <url>   (YouTube/TikTok/IG/FB/X)
╚══════════════════════╝

╔══════════════════════╗
✨ *AI Creative Commands*:
║ ➤ .roast @user
║ ➤ .rizz @user
║ ➤ .poem <topic>
║ ➤ .story <topic>
║ ➤ .haiku <topic>
║ ➤ .caption <context>
║ ➤ .explain <concept>
║ ➤ .code <task>
║ ➤ .debate <topic>
║ ➤ .advice <problem>
║ ➤ .recipe <dish>
║ ➤ .bio <description>
║ ➤ .pickup
║ ➤ .motivate <context>
║ ➤ .summarize (reply to msg)
╚══════════════════════╝

╔══════════════════════╗
🌐 *General Commands*:
║ ➤ .help or .menu
║ ➤ .ping
║ ➤ .alive
║ ➤ .tts <text>
║ ➤ .owner
║ ➤ .addowner <number>     ← add new owner
║ ➤ .removeowner <number>  ← remove owner
║ ➤ .listowners            ← list all owners
║ ➤ .joke
║ ➤ .quote
║ ➤ .fact
║ ➤ .weather <city>
║ ➤ .news
║ ➤ .attp <text>
║ ➤ .lyrics <song>
║ ➤ .8ball <question>
║ ➤ .groupinfo
║ ➤ .staff or .admins
║ ➤ .vv
║ ➤ .trt <text> <lang>
║ ➤ .ss <link>
║ ➤ .jid
║ ➤ .url
╚══════════════════════╝

╔══════════════════════╗
👮‍♂️ *Admin Commands*:
║ ➤ .ban @user
║ ➤ .promote @user
║ ➤ .demote @user
║ ➤ .mute <minutes>
║ ➤ .unmute
║ ➤ .delete or .del
║ ➤ .kick @user
║ ➤ .warn @user
║ ➤ .warnings @user
║ ➤ .antilink
║ ➤ .antibadword
║ ➤ .clear
║ ➤ .tag <message>
║ ➤ .tagall
║ ➤ .tagnotadmin
║ ➤ .hidetag <message>
║ ➤ .chatbot on/off ← AI auto-reply
║ ➤ .resetlink
║ ➤ .antitag <on/off>
║ ➤ .welcome <on/off>
║ ➤ .goodbye <on/off>
║ ➤ .setgdesc <desc>
║ ➤ .setgname <name>
║ ➤ .setgpp (reply image)
╚══════════════════════╝

╔══════════════════════╗
🔒 *Owner Commands*:
║ ➤ .mode <public/private>
║ ➤ .clearsession
║ ➤ .antidelete
║ ➤ .cleartmp
║ ➤ .update
║ ➤ .settings
║ ➤ .setpp (reply image)
║ ➤ .autoreact <on/off>
║ ➤ .autostatus <on/off>
║ ➤ .autotyping <on/off>
║ ➤ .autoread <on/off>
║ ➤ .anticall <on/off>
║ ➤ .pmblocker <on/off>
╚══════════════════════╝

╔══════════════════════╗
🎨 *Image/Sticker Commands*:
║ ➤ .blur (reply image)
║ ➤ .simage (reply sticker)
║ ➤ .sticker (reply image)
║ ➤ .removebg
║ ➤ .remini
║ ➤ .crop (reply image)
║ ➤ .tgsticker <link>
║ ➤ .meme
║ ➤ .take <packname>
║ ➤ .emojimix <e1>+<e2>
╚══════════════════════╝

╔══════════════════════╗
🎮 *Game Commands*:
║ ➤ .tictactoe @user
║ ➤ .hangman         ← start hangman
║ ➤ .guess <letter>  ← guess a letter
║ ➤ .hstop           ← stop hangman
║ ➤ .trivia
║ ➤ .answer <answer>
║ ➤ .truth
║ ➤ .dare
╚══════════════════════╝

╔══════════════════════╗
🎯 *Fun Commands*:
║ ➤ .compliment @user
║ ➤ .insult @user
║ ➤ .flirt
║ ➤ .shayari
║ ➤ .goodnight
║ ➤ .roseday
║ ➤ .character @user
║ ➤ .wasted @user
║ ➤ .ship @user
║ ➤ .simp @user
║ ➤ .stupid @user
╚══════════════════════╝

╔══════════════════════╗
📥 *Downloader*:
║ ➤ .play <song_name>
║ ➤ .song <song_name>
║ ➤ .spotify <query>
║ ➤ .instagram <link>
║ ➤ .facebook <link>
║ ➤ .tiktok <link>
║ ➤ .video <name>
║ ➤ .ytmp4 <link>
╚══════════════════════╝

╔══════════════════════╗
🔤 *Textmaker*:
║ ➤ .metallic .ice .snow
║ ➤ .matrix .neon .fire
║ ➤ .glitch .hacker .devil
║ ➤ .thunder .arena .1917
╚══════════════════════╝

_LUNR BOT v${settings.version} • Real AI Inside 🧠_`;

  try {
    const imagePath = path.join(__dirname, '../assets/bot_image.jpg');
    if (fs.existsSync(imagePath)) {
      const imageBuffer = fs.readFileSync(imagePath);
      await sock.sendMessage(chatId, {
        image: imageBuffer,
        caption: helpMessage,
      }, { quoted: message });
    } else {
      await sock.sendMessage(chatId, { text: helpMessage }, { quoted: message });
    }
  } catch (err) {
    console.error('[HELP] Error:', err);
    await sock.sendMessage(chatId, { text: helpMessage }, { quoted: message });
  }
}

module.exports = helpCommand;
