/**
 * LUNR BOT — Add/Remove Owner Command
 * Commands:
 *   .addowner <number>   — add a new owner number
 *   .removeowner <number> — remove an owner number
 *   .listowners          — list all owner numbers
 */

const fs = require('fs');
const path = require('path');
const isOwnerOrSudo = require('../lib/isOwner');

const OWNER_FILE = path.join(__dirname, '../data/owner.json');

function readOwners() {
  try {
    const data = fs.readFileSync(OWNER_FILE, 'utf8');
    const parsed = JSON.parse(data);
    return Array.isArray(parsed) ? parsed : [parsed];
  } catch {
    return [];
  }
}

function writeOwners(owners) {
  fs.writeFileSync(OWNER_FILE, JSON.stringify(owners, null, 2));
}

function cleanNumber(num) {
  return num.replace(/[^0-9]/g, '');
}

async function addOwnerCommand(sock, chatId, message) {
  const senderId = message.key.participant || message.key.remoteJid;
  const isOwner = message.key.fromMe || await isOwnerOrSudo(senderId, sock, chatId);

  if (!message.key.fromMe && !isOwner) {
    return await sock.sendMessage(chatId, {
      text: '❌ Only the *bot owner* can use owner management commands.',
    }, { quoted: message });
  }

  const rawText =
    message.message?.conversation?.trim() ||
    message.message?.extendedTextMessage?.text?.trim() || '';

  const parts = rawText.trim().split(/\s+/);
  const cmd = parts[0].toLowerCase();

  // .listowners
  if (cmd === '.listowners') {
    const owners = readOwners();
    if (owners.length === 0) {
      return await sock.sendMessage(chatId, { text: '📋 No owners configured.' }, { quoted: message });
    }
    const list = owners.map((n, i) => `${i + 1}. +${n}`).join('\n');
    return await sock.sendMessage(chatId, {
      text: `👑 *Owner List:*\n\n${list}`,
    }, { quoted: message });
  }

  const numberArg = parts[1];
  if (!numberArg) {
    return await sock.sendMessage(chatId, {
      text: `❌ Please provide a number.\n\nUsage:\n• *.addowner* 2348012345678\n• *.removeowner* 2348012345678\n• *.listowners*`,
    }, { quoted: message });
  }

  const cleaned = cleanNumber(numberArg);
  if (cleaned.length < 7 || cleaned.length > 15) {
    return await sock.sendMessage(chatId, {
      text: `❌ Invalid number format. Use full international format without + or spaces.\nExample: *.addowner* 2348012345678`,
    }, { quoted: message });
  }

  const owners = readOwners();

  // .addowner
  if (cmd === '.addowner') {
    if (owners.includes(cleaned)) {
      return await sock.sendMessage(chatId, {
        text: `⚠️ *+${cleaned}* is already an owner.`,
      }, { quoted: message });
    }
    owners.push(cleaned);
    writeOwners(owners);
    return await sock.sendMessage(chatId, {
      text: `✅ *+${cleaned}* has been added as an owner!\n\nThey now have full bot access.`,
    }, { quoted: message });
  }

  // .removeowner
  if (cmd === '.removeowner') {
    const idx = owners.indexOf(cleaned);
    if (idx === -1) {
      return await sock.sendMessage(chatId, {
        text: `⚠️ *+${cleaned}* is not in the owner list.`,
      }, { quoted: message });
    }
    if (owners.length === 1) {
      return await sock.sendMessage(chatId, {
        text: `❌ Cannot remove the last owner. There must be at least one owner.`,
      }, { quoted: message });
    }
    owners.splice(idx, 1);
    writeOwners(owners);
    return await sock.sendMessage(chatId, {
      text: `✅ *+${cleaned}* has been removed from the owner list.`,
    }, { quoted: message });
  }
}

module.exports = addOwnerCommand;
