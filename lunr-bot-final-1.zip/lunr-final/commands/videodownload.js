/**
 * LUNR BOT — Universal Video Downloader
 * Command: .dl <url>  or  .download <url>
 * Supports: YouTube, TikTok, Instagram, Facebook, Twitter/X, and more
 */

const https = require('https');
const http = require('http');
const { URL } = require('url');
const { exec } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

function detectPlatform(url) {
  if (/youtube\.com|youtu\.be/.test(url)) return 'YouTube';
  if (/tiktok\.com/.test(url)) return 'TikTok';
  if (/instagram\.com/.test(url)) return 'Instagram';
  if (/facebook\.com|fb\.watch/.test(url)) return 'Facebook';
  if (/twitter\.com|x\.com/.test(url)) return 'Twitter/X';
  if (/pinterest\.com/.test(url)) return 'Pinterest';
  if (/reddit\.com/.test(url)) return 'Reddit';
  if (/vimeo\.com/.test(url)) return 'Vimeo';
  if (/dailymotion\.com/.test(url)) return 'Dailymotion';
  return 'Video';
}

function isValidUrl(url) {
  try {
    new URL(url);
    return true;
  } catch {
    return false;
  }
}

// Try yt-dlp first (most reliable)
function downloadWithYtDlp(url, outputPath) {
  return new Promise((resolve, reject) => {
    const cmd = `yt-dlp -f "bestvideo[height<=720][ext=mp4]+bestaudio[ext=m4a]/best[height<=720][ext=mp4]/best[height<=720]/best" --merge-output-format mp4 --max-filesize 50m -o "${outputPath}" "${url}" 2>&1`;
    exec(cmd, { timeout: 120000 }, (err, stdout, stderr) => {
      if (err) return reject(new Error(stdout || stderr || err.message));
      resolve(outputPath);
    });
  });
}

// Fallback: cobalt.tools API (free, no key)
async function downloadWithCobalt(url) {
  const res = await fetch('https://api.cobalt.tools/api/json', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    },
    body: JSON.stringify({
      url,
      vQuality: '720',
      vCodec: 'h264',
      isAudioOnly: false,
      disableMetadata: true,
    }),
  });

  if (!res.ok) throw new Error(`Cobalt API error ${res.status}`);
  const data = await res.json();

  if (data.status === 'error') throw new Error(data.text || 'Cobalt failed');
  if (data.status === 'redirect' || data.status === 'stream') return data.url;
  if (data.status === 'picker') return data.picker?.[0]?.url;
  throw new Error('Unsupported response from Cobalt');
}

async function fetchBuffer(url) {
  return new Promise((resolve, reject) => {
    const parsedUrl = new URL(url);
    const client = parsedUrl.protocol === 'https:' ? https : http;
    const req = client.get(url, { timeout: 60000, headers: { 'User-Agent': 'Mozilla/5.0' } }, (res) => {
      if (res.statusCode === 301 || res.statusCode === 302) {
        return fetchBuffer(res.headers.location).then(resolve).catch(reject);
      }
      if (res.statusCode !== 200) return reject(new Error(`HTTP ${res.statusCode}`));
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => resolve(Buffer.concat(chunks)));
      res.on('error', reject);
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('Download timed out')); });
  });
}

async function videoDownloadCommand(sock, chatId, message) {
  try {
    const rawText =
      message.message?.conversation?.trim() ||
      message.message?.extendedTextMessage?.text?.trim() || '';

    const parts = rawText.trim().split(/\s+/);
    const cmd = parts[0].toLowerCase();
    if (cmd !== '.dl' && cmd !== '.download') return;

    const url = parts[1];
    if (!url || !isValidUrl(url)) {
      return await sock.sendMessage(chatId, {
        text: `📥 *Video Downloader*\n\nUsage: *.dl* <video link>\n\nSupported:\n• YouTube\n• TikTok\n• Instagram Reels\n• Facebook Videos\n• Twitter/X Videos\n• Reddit Videos\n• Vimeo\n• And more!\n\nExample:\n*.dl* https://www.youtube.com/watch?v=...`,
      }, { quoted: message });
    }

    const platform = detectPlatform(url);
    await sock.sendMessage(chatId, { react: { text: '📥', key: message.key } });
    await sock.sendMessage(chatId, {
      text: `📥 *Downloading ${platform} video...*\nThis may take a moment.`,
    }, { quoted: message });

    let videoBuffer = null;
    let method = '';

    // Method 1: yt-dlp (if installed)
    try {
      const tmpFile = path.join(os.tmpdir(), `lunr_dl_${Date.now()}.mp4`);
      await downloadWithYtDlp(url, tmpFile);
      if (fs.existsSync(tmpFile)) {
        const stat = fs.statSync(tmpFile);
        if (stat.size > 0 && stat.size < 60 * 1024 * 1024) { // max 60MB
          videoBuffer = fs.readFileSync(tmpFile);
          fs.unlinkSync(tmpFile);
          method = 'yt-dlp';
        }
      }
    } catch (e) {
      console.log('[DL] yt-dlp failed, trying cobalt:', e.message);
    }

    // Method 2: cobalt.tools API
    if (!videoBuffer) {
      try {
        const dlUrl = await downloadWithCobalt(url);
        videoBuffer = await fetchBuffer(dlUrl);
        method = 'cobalt.tools';
      } catch (e) {
        console.log('[DL] Cobalt failed:', e.message);
      }
    }

    if (!videoBuffer || videoBuffer.length === 0) {
      return await sock.sendMessage(chatId, {
        text: `❌ *Could not download this video.*\n\nThe link may be:\n• Private or restricted\n• Unsupported format\n• Too large (>60MB)\n\nTry these tools:\n• https://cobalt.tools\n• https://yt1s.com\n• https://savefrom.net`,
      }, { quoted: message });
    }

    // Size check (WhatsApp limit ~64MB)
    const sizeMB = (videoBuffer.length / (1024 * 1024)).toFixed(1);
    if (videoBuffer.length > 64 * 1024 * 1024) {
      return await sock.sendMessage(chatId, {
        text: `❌ Video is too large (${sizeMB}MB). WhatsApp limit is ~64MB.\n\nFor large videos, try:\n• https://cobalt.tools (direct download)\n• https://yt1s.com`,
      }, { quoted: message });
    }

    await sock.sendMessage(chatId, {
      video: videoBuffer,
      caption: `📥 *${platform} Video*\n_${sizeMB}MB • Downloaded by LUNR BOT_`,
      mimetype: 'video/mp4',
    }, { quoted: message });

    await sock.sendMessage(chatId, { react: { text: '✅', key: message.key } });

  } catch (err) {
    console.error('[VIDEODOWNLOAD] Error:', err.message);
    await sock.sendMessage(chatId, {
      text: `❌ *Download failed*\n\n_${err.message}_\n\nTry these alternatives:\n• https://cobalt.tools\n• https://yt1s.com\n• https://savefrom.net\n• https://ssstik.io (TikTok)`,
    }, { quoted: message });
    await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } });
  }
}

module.exports = videoDownloadCommand;
