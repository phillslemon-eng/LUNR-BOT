const fs = require('fs');

const words = [
  // Tech & Internet
  'javascript', 'python', 'algorithm', 'database', 'cryptocurrency', 'blockchain',
  'artificial', 'intelligence', 'programming', 'developer', 'software', 'hardware',
  'internet', 'bandwidth', 'download', 'upload', 'password', 'encryption',
  // Animals
  'elephant', 'crocodile', 'butterfly', 'chimpanzee', 'hippopotamus', 'kangaroo',
  'rhinoceros', 'salamander', 'chameleon', 'platypus', 'wolverine', 'armadillo',
  // Countries & Places
  'australia', 'argentina', 'portugal', 'indonesia', 'cameroon', 'madagascar',
  'switzerland', 'mozambique', 'singapore', 'venezuela', 'caribbean', 'himalaya',
  // Food
  'chocolate', 'spaghetti', 'hamburger', 'avocado', 'pineapple', 'watermelon',
  'strawberry', 'blueberry', 'cinnamon', 'cauliflower', 'mozzarella', 'guacamole',
  // Sports
  'basketball', 'volleyball', 'badminton', 'swimming', 'gymnastics', 'wrestling',
  'skateboard', 'marathon', 'triathlon', 'snowboard', 'archery', 'fencing',
  // General
  'adventure', 'beautiful', 'knowledge', 'universe', 'mountain', 'hospital',
  'education', 'democracy', 'telescope', 'orchestra', 'labyrinth', 'phenomenon',
  'hurricane', 'lightning', 'avalanche', 'mystery', 'champion', 'paradise',
  'moonlight', 'sunshine', 'treasure', 'rainbow', 'volcano', 'diamond',
];

const HANGMAN_ART = [
  '```\n  +---+\n  |   |\n      |\n      |\n      |\n      |\n=========```',
  '```\n  +---+\n  |   |\n  O   |\n      |\n      |\n      |\n=========```',
  '```\n  +---+\n  |   |\n  O   |\n  |   |\n      |\n      |\n=========```',
  '```\n  +---+\n  |   |\n  O   |\n /|   |\n      |\n      |\n=========```',
  '```\n  +---+\n  |   |\n  O   |\n /|\\  |\n      |\n      |\n=========```',
  '```\n  +---+\n  |   |\n  O   |\n /|\\  |\n /    |\n      |\n=========```',
  '```\n  +---+\n  |   |\n  O   |\n /|\\  |\n / \\  |\n      |\n=========```',
];

let hangmanGames = {};

function buildStatus(game) {
  const display = game.maskedWord.join(' ');
  const art = HANGMAN_ART[game.wrongGuesses];
  const guessed = game.guessedLetters.length ? game.guessedLetters.join(', ') : 'None';
  const remaining = game.maxWrongGuesses - game.wrongGuesses;
  return `${art}\n\n📝 *Word:* ${display}\n❌ *Wrong guesses:* ${game.wrongGuesses}/${game.maxWrongGuesses}\n💡 *Letters tried:* ${guessed}\n❤️ *Lives left:* ${remaining}`;
}

function startHangman(sock, chatId, message) {
  const word = words[Math.floor(Math.random() * words.length)];
  const maskedWord = Array(word.length).fill('_');

  hangmanGames[chatId] = {
    word,
    maskedWord,
    guessedLetters: [],
    wrongGuesses: 0,
    maxWrongGuesses: 6,
  };

  const status = buildStatus(hangmanGames[chatId]);
  sock.sendMessage(chatId, {
    text: `🎮 *HANGMAN GAME STARTED!*\n\nGuess the *${word.length}-letter* word!\n\n${status}\n\n_Type a letter to guess. E.g: *a*_\nType *.hstop* to end the game.`,
  }, { quoted: message });
}

function guessLetter(sock, chatId, letter, message) {
  if (!hangmanGames[chatId]) {
    sock.sendMessage(chatId, { text: '❌ No game in progress. Start one with *.hangman*' }, { quoted: message });
    return;
  }

  const game = hangmanGames[chatId];
  const { word, guessedLetters, maskedWord, maxWrongGuesses } = game;

  if (guessedLetters.includes(letter)) {
    sock.sendMessage(chatId, { text: `⚠️ You already guessed *"${letter}"*. Try another letter!\n\n${buildStatus(game)}` }, { quoted: message });
    return;
  }

  guessedLetters.push(letter);

  if (word.includes(letter)) {
    for (let i = 0; i < word.length; i++) {
      if (word[i] === letter) maskedWord[i] = letter;
    }

    if (!maskedWord.includes('_')) {
      sock.sendMessage(chatId, {
        text: `🎉 *CONGRATULATIONS!* You won!\n\n🟢 The word was: *${word.toUpperCase()}*\n\nType *.hangman* to play again!`,
      }, { quoted: message });
      delete hangmanGames[chatId];
    } else {
      sock.sendMessage(chatId, { text: `✅ *Nice guess!* "${letter}" is in the word!\n\n${buildStatus(game)}` }, { quoted: message });
    }
  } else {
    game.wrongGuesses += 1;

    if (game.wrongGuesses >= maxWrongGuesses) {
      sock.sendMessage(chatId, {
        text: `💀 *GAME OVER!*\n\n${HANGMAN_ART[6]}\n\nThe word was: *${word.toUpperCase()}*\n\nType *.hangman* to try again!`,
      }, { quoted: message });
      delete hangmanGames[chatId];
    } else {
      sock.sendMessage(chatId, { text: `❌ Wrong! *"${letter}"* is not in the word.\n\n${buildStatus(game)}` }, { quoted: message });
    }
  }
}

function stopHangman(sock, chatId, message) {
  if (!hangmanGames[chatId]) {
    sock.sendMessage(chatId, { text: '❌ No active hangman game to stop.' }, { quoted: message });
    return;
  }
  const word = hangmanGames[chatId].word;
  delete hangmanGames[chatId];
  sock.sendMessage(chatId, { text: `🛑 Game stopped. The word was: *${word.toUpperCase()}*` }, { quoted: message });
}

module.exports = { startHangman, guessLetter, stopHangman };
