/**
 * LUNR BOT — Veo Video Generation
 * Command: .veo <prompt>
 * Uses: Google Veo 2 via Gemini API (cheapest Veo model)
 */

require('dotenv').config();

async function veoCommand(sock, chatId, message) {
  try {
    const rawText =
      message.message?.conversation?.trim() ||
      message.message?.extendedTextMessage?.text?.trim() || '';

    const parts = rawText.split(/\s+/);
    const cmd = parts[0].toLowerCase();
    if (cmd !== '.veo') return;

    const prompt = parts.slice(1).join(' ').trim();
    if (!prompt) {
      return await sock.sendMessage(chatId, {
        text: `🎬 *Veo Video Generator*\n\nUsage: *.veo* <your prompt>\nExample: *.veo* a lion running across the savanna at sunset\n\n⚠️ _Video generation takes 2–5 minutes. Please be patient!_\n\n_Powered by Google Veo 2_`,
      }, { quoted: message });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey === 'YOUR_GEMINI_KEY') {
      return await sock.sendMessage(chatId, {
        text: `❌ Gemini API key not configured.\n\nGet your FREE key at: https://aistudio.google.com\nSign in → Get API Key → Create Key\nThen add to *.env*:\n*GEMINI_API_KEY=your_key_here*\n\n_Note: Veo requires billing enabled on your Google Cloud account._`,
      }, { quoted: message });
    }

    await sock.sendMessage(chatId, { react: { text: '🎬', key: message.key } });
    await sock.sendMessage(chatId, {
      text: `🎬 *Starting Veo video generation...*\n\n📝 Prompt: _${prompt}_\n\n⏳ This takes *2–5 minutes*. You'll receive the video when ready!`,
    }, { quoted: message });

    // Step 1: Start the video generation job (async)
    const startRes = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/veo-2.0-generate-001:predictLongRunning?key=${apiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          instances: [{
            prompt,
          }],
          parameters: {
            aspectRatio: '9:16',
            durationSeconds: 5,
            sampleCount: 1,
            enhancePrompt: true,
          },
        }),
      }
    );

    if (!startRes.ok) {
      const err = await startRes.json();
      const errMsg = err.error?.message || `API error ${startRes.status}`;
      if (startRes.status === 429 || startRes.status === 403) {
        return await sock.sendMessage(chatId, {
          text: `❌ *Veo access restricted or quota exceeded.*\n\nVeo requires:\n• Billing enabled on Google Cloud\n• Vertex AI API access\n\nAlternatives:\n• Check quota: https://aistudio.google.com\n• Enable billing: https://console.cloud.google.com/billing\n• Vertex AI docs: https://cloud.google.com/vertex-ai/generative-ai/docs/video/generate-videos`,
        }, { quoted: message });
      }
      throw new Error(errMsg);
    }

    const job = await startRes.json();
    const operationName = job.name;
    if (!operationName) throw new Error('No operation ID returned from Veo');

    // Step 2: Poll for completion (max 10 min)
    const maxWait = 10 * 60 * 1000;
    const pollInterval = 15 * 1000;
    const startTime = Date.now();
    let videoData = null;

    while (Date.now() - startTime < maxWait) {
      await new Promise(r => setTimeout(r, pollInterval));

      const pollRes = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/${operationName}?key=${apiKey}`,
        { method: 'GET' }
      );

      if (!pollRes.ok) continue;
      const pollData = await pollRes.json();

      if (pollData.done) {
        if (pollData.error) throw new Error(pollData.error.message || 'Veo generation failed');
        videoData = pollData.response?.predictions?.[0];
        break;
      }
    }

    if (!videoData) throw new Error('Video generation timed out (>10 min). Try a simpler prompt.');

    // Step 3: Download and send the video
    const videoB64 = videoData.bytesBase64Encoded;
    const videoUri = videoData.video?.uri;

    let videoBuffer;
    if (videoB64) {
      videoBuffer = Buffer.from(videoB64, 'base64');
    } else if (videoUri) {
      const vRes = await fetch(videoUri);
      const ab = await vRes.arrayBuffer();
      videoBuffer = Buffer.from(ab);
    } else {
      throw new Error('No video data in response');
    }

    await sock.sendMessage(chatId, {
      video: videoBuffer,
      caption: `🎬 *Veo 2 Video*\n\n📝 *Prompt:* ${prompt}\n\n_Powered by Google Veo 2 | LUNR BOT_`,
      mimetype: 'video/mp4',
    }, { quoted: message });

    await sock.sendMessage(chatId, { react: { text: '✅', key: message.key } });

  } catch (err) {
    console.error('[VEO] Error:', err.message);
    await sock.sendMessage(chatId, {
      text: `❌ *Veo video generation failed*\n\n_${err.message}_\n\nHelp & Docs:\n• https://aistudio.google.com\n• https://cloud.google.com/vertex-ai/generative-ai/docs/video/generate-videos`,
    }, { quoted: message });
    await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } });
  }
}

module.exports = veoCommand;
