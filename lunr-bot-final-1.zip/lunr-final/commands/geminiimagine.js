/**
 * LUNR BOT — Gemini Image Generation
 * Command: .geminiimagine <prompt>
 * Uses: Google Imagen 3 via Gemini API
 */

require('dotenv').config();

async function geminiImagineCommand(sock, chatId, message) {
  try {
    const rawText =
      message.message?.conversation?.trim() ||
      message.message?.extendedTextMessage?.text?.trim() || '';

    const parts = rawText.split(/\s+/);
    const cmd = parts[0].toLowerCase();
    if (cmd !== '.lunrv2') return;

    const prompt = parts.slice(1).join(' ').trim();
    if (!prompt) {
      return await sock.sendMessage(chatId, {
        text: `🖼️ *Gemini Image Generator*\n\nUsage: *.lunrv2* <your prompt>\nExample: *.lunrv2* a sunset over african savanna with elephants\n\n_Powered by Google Imagen 3_`,
      }, { quoted: message });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey === 'YOUR_GEMINI_KEY') {
      return await sock.sendMessage(chatId, {
        text: `❌ Gemini API key not configured.\n\nGet your FREE key at: https://aistudio.google.com\nSign in → Get API Key → Create Key\nThen add to *.env*:\n*GEMINI_API_KEY=your_key_here*`,
      }, { quoted: message });
    }

    await sock.sendMessage(chatId, { react: { text: '🖼️', key: message.key } });
    await sock.sendMessage(chatId, {
      text: '🖼️ *Generating image with Google Imagen 3...*\nThis may take 15–30 seconds.',
    }, { quoted: message });

    // Gemini Imagen 3 endpoint
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/imagen-3.0-generate-001:predict?key=${apiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          instances: [{ prompt }],
          parameters: {
            sampleCount: 1,
            aspectRatio: '1:1',
            safetyFilterLevel: 'block_some',
            personGeneration: 'allow_adult',
          },
        }),
      }
    );

    if (!response.ok) {
      const err = await response.json();
      const errMsg = err.error?.message || `API error ${response.status}`;
      // Friendly error for quota/billing issues
      if (response.status === 429 || response.status === 403) {
        return await sock.sendMessage(chatId, {
          text: `❌ *Gemini quota reached or API restricted.*\n\nTry:\n• Use *.imagine* (free, no key needed)\n• Check quota: https://aistudio.google.com\n• Enable billing: https://console.cloud.google.com`,
        }, { quoted: message });
      }
      throw new Error(errMsg);
    }

    const data = await response.json();
    const b64 = data.predictions?.[0]?.bytesBase64Encoded;
    if (!b64) throw new Error('No image returned from Gemini');

    const imageBuffer = Buffer.from(b64, 'base64');

    await sock.sendMessage(chatId, {
      image: imageBuffer,
      caption: `🖼️ *Gemini Imagen 3*\n\n📝 *Prompt:* ${prompt}\n\n_Powered by Google Imagen 3 | LUNR BOT_`,
    }, { quoted: message });

    await sock.sendMessage(chatId, { react: { text: '✅', key: message.key } });

  } catch (err) {
    console.error('[GEMINIIMAGINE] Error:', err.message);
    await sock.sendMessage(chatId, {
      text: `❌ *Gemini Image generation failed*\n\n${err.message}\n\nAlternatives:\n• Try *.imagine* (free, no key)\n• Visit: https://aistudio.google.com for help`,
    }, { quoted: message });
    await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } });
  }
}

module.exports = geminiImagineCommand;
