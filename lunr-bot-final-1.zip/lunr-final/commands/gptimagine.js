/**
 * LUNR BOT — GPT Image Generation
 * Command: .gptimagine <prompt>
 * Uses: OpenAI DALL-E 3
 */

require('dotenv').config();

async function gptImagineCommand(sock, chatId, message) {
  try {
    const rawText =
      message.message?.conversation?.trim() ||
      message.message?.extendedTextMessage?.text?.trim() || '';

    const parts = rawText.split(/\s+/);
    const cmd = parts[0].toLowerCase();
    if (cmd !== '.lunr') return;

    const prompt = parts.slice(1).join(' ').trim();
    if (!prompt) {
      return await sock.sendMessage(chatId, {
        text: `🎨 *GPT Image Generator*\n\nUsage: *.lunr* <your prompt>\nExample: *.lunr* a futuristic city at night with neon lights\n\n_Powered by OpenAI DALL-E 3_`,
      }, { quoted: message });
    }

    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey || apiKey === 'YOUR_OPENAI_KEY') {
      return await sock.sendMessage(chatId, {
        text: `❌ OpenAI API key not configured.\n\nGet your free key at: https://platform.openai.com/api-keys\nThen add it to your *.env* file as:\n*OPENAI_API_KEY=your_key_here*`,
      }, { quoted: message });
    }

    await sock.sendMessage(chatId, { react: { text: '🎨', key: message.key } });
    await sock.sendMessage(chatId, {
      text: '🎨 *Generating image with DALL-E 3...*\nThis may take 15–30 seconds.',
    }, { quoted: message });

    const response = await fetch('https://api.openai.com/v1/images/generations', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: 'dall-e-3',
        prompt,
        n: 1,
        size: '1024x1024',
        quality: 'standard',
      }),
    });

    if (!response.ok) {
      const err = await response.json();
      throw new Error(err.error?.message || `API error ${response.status}`);
    }

    const data = await response.json();
    const imageUrl = data.data?.[0]?.url;
    if (!imageUrl) throw new Error('No image URL returned');

    // Fetch the image buffer
    const imgRes = await fetch(imageUrl);
    if (!imgRes.ok) throw new Error('Failed to download generated image');
    const arrayBuffer = await imgRes.arrayBuffer();
    const imageBuffer = Buffer.from(arrayBuffer);

    await sock.sendMessage(chatId, {
      image: imageBuffer,
      caption: `🎨 *DALL-E 3 Image*\n\n📝 *Prompt:* ${prompt}\n\n_Powered by OpenAI DALL-E 3 | LUNR BOT_`,
    }, { quoted: message });

    await sock.sendMessage(chatId, { react: { text: '✅', key: message.key } });

  } catch (err) {
    console.error('[GPTIMAGINE] Error:', err.message);
    await sock.sendMessage(chatId, {
      text: `❌ *GPT Image generation failed*\n\n${err.message}\n\nTry again or visit: https://platform.openai.com/docs/guides/images`,
    }, { quoted: message });
    await sock.sendMessage(chatId, { react: { text: '❌', key: message.key } });
  }
}

module.exports = gptImagineCommand;
