/**
 * Image Generation Commands
 * Handles: .imagine  .flux  .dalle  .art  .draw  .paint
 *
 * Uses pollinations.ai — completely FREE, no API key required.
 * Returns high-quality AI-generated images.
 */

const settings = require('../settings');
const https = require('https');
const http = require('http');
const { URL } = require('url');

const IMAGE_COMMANDS = new Set(['.imagine', '.flux', '.dalle', '.art', '.draw', '.paint']);

// Style presets
const STYLES = {
  '.imagine': 'photorealistic, high detail, 8k resolution, professional photography, sharp focus',
  '.flux':    'flux style, cinematic, dramatic lighting, ultra detailed, masterpiece',
  '.dalle':   'digital art, clean lines, vibrant colors, professional illustration',
  '.art':     'fine art, painterly, artistic, expressive brushwork, gallery quality',
  '.draw':    'detailed pencil sketch, cross-hatching, artistic illustration',
  '.paint':   'oil painting, impasto technique, rich colors, painterly texture, masterpiece',
};

async function fetchImageBuffer(url) {
  return new Promise((resolve, reject) => {
    const parsedUrl = new URL(url);
    const client = parsedUrl.protocol === 'https:' ? https : http;

    const req = client.get(url, { timeout: 60000 }, (res) => {
      // Handle redirects
      if (res.statusCode === 301 || res.statusCode === 302) {
        return fetchImageBuffer(res.headers.location).then(resolve).catch(reject);
      }
      if (res.statusCode !== 200) {
        return reject(new Error(`HTTP ${res.statusCode}`));
      }

      const chunks = [];
      res.on('data', (chunk) => chunks.push(chunk));
      res.on('end', () => resolve(Buffer.concat(chunks)));
      res.on('error', reject);
    });

    req.on('error', reject);
    req.on('timeout', () => {
      req.destroy();
      reject(new Error('Request timed out'));
    });
  });
}

async function imagineCommand(sock, chatId, message) {
  try {
    const rawText =
      message.message?.conversation?.trim() ||
      message.message?.extendedTextMessage?.text?.trim() ||
      '';

    const parts = rawText.split(/\s+/);
    const cmd = parts[0].toLowerCase();

    if (!IMAGE_COMMANDS.has(cmd)) return;

    const prompt = parts.slice(1).join(' ').trim();

    if (!prompt) {
      return await sock.sendMessage(chatId, {
        text: `🎨 Please provide an image prompt.\nExample: *${cmd}* a cyberpunk city at night with neon lights`,
      }, { quoted: message });
    }

    // React to show we're working
    await sock.sendMessage(chatId, {
      react: { text: '🎨', key: message.key },
    });

    await sock.sendMessage(chatId, {
      text: '🎨 Generating your image... This may take 10–30 seconds.',
    }, { quoted: message });

    // Build enhanced prompt
    const styleTag = STYLES[cmd] || STYLES['.imagine'];
    const fullPrompt = `${prompt}, ${styleTag}`;
    const negativePrompt = 'blurry, low quality, watermark, text, ugly, deformed';

    // pollinations.ai free API
    const seed = Math.floor(Math.random() * 1000000);
    const imageUrl =
      `https://image.pollinations.ai/prompt/${encodeURIComponent(fullPrompt)}` +
      `?width=1024&height=1024&seed=${seed}&nologo=true&negative=${encodeURIComponent(negativePrompt)}`;

    const imageBuffer = await fetchImageBuffer(imageUrl);

    await sock.sendMessage(chatId, {
      image: imageBuffer,
      caption: `🎨 *Prompt:* ${prompt}\n*Style:* ${cmd.slice(1)}\n\n_Powered by Pollinations AI_`,
    }, { quoted: message });

    await sock.sendMessage(chatId, {
      react: { text: '✅', key: message.key },
    });

  } catch (err) {
    console.error('[IMAGINE] Error:', err.message);
    await sock.sendMessage(chatId, {
      text: `❌ Image generation failed: ${err.message}\nTry again or use a different prompt.`,
    }, { quoted: message });
  }
}

imagineCommand.COMMANDS = IMAGE_COMMANDS;
module.exports = imagineCommand;
