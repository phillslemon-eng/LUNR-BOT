/**
 * .summarize / .tldr — powered by free AI engine
 */

async function summarizeCommand(sock, chatId, message) {
  try {
    const { callGemini, callGroq, callPollinations } = require('./ai');

    const rawText = message.message?.conversation?.trim() || message.message?.extendedTextMessage?.text?.trim() || '';
    const quotedMsg = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const quotedText = quotedMsg?.conversation || quotedMsg?.extendedTextMessage?.text || '';
    const cmd = rawText.split(/\s+/)[0].toLowerCase();
    const inlineText = rawText.slice(cmd.length).trim();
    const toSummarize = inlineText || quotedText;

    if (!toSummarize) {
      return sock.sendMessage(chatId, {
        text: '📝 Reply to a message with *.summarize* or provide text after the command.',
      }, { quoted: message });
    }

    await sock.sendMessage(chatId, { react: { text: '📝', key: message.key } });

    const prompt = `Summarize in 3–5 bullet points. Be concise:\n\n${toSummarize}`;
    const messages = [{ role: 'user', content: prompt }];
    let summary = null;

    for (const fn of [
      () => callPollinations(messages, null),
      () => callGemini(messages, null),
      () => callGroq(messages, null),
    ]) {
      try { summary = await fn(); break; } catch { continue; }
    }

    if (!summary) throw new Error('All providers failed');

    await sock.sendMessage(chatId, { text: `📝 *Summary:*\n\n${summary}` }, { quoted: message });

  } catch (err) {
    console.error('[SUMMARIZE]', err.message);
    await sock.sendMessage(chatId, { text: `❌ ${err.message}` }, { quoted: message });
  }
}

module.exports = summarizeCommand;
