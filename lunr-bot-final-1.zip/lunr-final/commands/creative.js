/**
 * Creative AI Commands — all powered by free providers via ai.js
 * .roast .rizz .poem .story .haiku .caption .explain .code
 * .debate .advice .recipe .bio .pickup .motivate .fact .joke
 * .quote .translate .summarize
 */

const settings = require('../settings');

async function freeAI(prompt, maxTokens = 300) {
  const { callGemini, callGroq, callPollinations } = require('./ai');
  const messages = [{ role: 'user', content: prompt }];

  for (const fn of [
    () => callPollinations(messages, null),
    () => callGemini(messages, null),
    () => callGroq(messages, null),
  ]) {
    try { return await fn(); } catch { continue; }
  }
  throw new Error('All AI providers unavailable. Try again later.');
}

const CREATIVE_COMMANDS = {
  '.roast': async (args, mentionName) => {
    const t = mentionName || args || 'this person';
    return freeAI(`Write a funny lighthearted roast for someone named "${t}". Playful, not mean. 2–3 sentences. Add emojis.`);
  },
  '.compliment': async (args, mentionName) => {
    const t = mentionName || args || 'this person';
    return freeAI(`Write a genuine creative compliment for someone named "${t}". 1–2 sentences. Add a warm emoji.`);
  },
  '.rizz': async (args, mentionName) => {
    const t = mentionName || args || 'them';
    return freeAI(`Write a smooth charming rizz line for someone named "${t}". Witty, not cheesy. Clean and fun. Add emojis.`);
  },
  '.poem': async (args) =>
    freeAI(`Write a short creative poem about "${args || 'friendship'}". 4–8 lines. Beautiful and memorable.`),
  '.story': async (args) =>
    freeAI(`Write a short story (5–8 sentences) about "${args || 'a mysterious adventure'}". Engaging with a twist ending.`),
  '.haiku': async (args) =>
    freeAI(`Write a traditional haiku (5-7-5 syllables) about "${args || 'nature'}". Show only the haiku.`),
  '.caption': async (args) =>
    freeAI(`Write 3 creative Instagram captions for "${args || 'a cool photo'}". Include emojis and hashtags. Number them 1, 2, 3.`),
  '.explain': async (args) =>
    freeAI(`Explain "${args || 'quantum physics'}" to a 5-year-old. Simple analogy, under 4 sentences. Fun and engaging.`),
  '.code': async (args) =>
    freeAI(`Write clean commented code for: "${args || 'hello world in Python'}". Include a brief explanation.`),
  '.debate': async (args) =>
    freeAI(`Give the strongest argument IN FAVOR of "${args || 'pineapple on pizza'}". Devil's advocate. 3 bullet points. Add emojis.`),
  '.advice': async (args) =>
    freeAI(`Give wise practical advice about "${args || 'life'}". 3–4 sentences, genuine and helpful. Add emojis.`),
  '.recipe': async (args) =>
    freeAI(`Simple recipe for "${args || 'pasta carbonara'}". Bullet point ingredients, then numbered steps. Concise.`),
  '.bio': async (args) =>
    freeAI(`Creative funny social media bio for someone described as "${args || 'a mysterious stranger'}". 2–3 sentences. Emojis + hashtags.`),
  '.pickup': async () =>
    freeAI('Generate a clever original pickup line. Witty not cheesy. Clean and fun. Add emojis.'),
  '.motivate': async (args) =>
    freeAI(`Powerful motivational message about "${args || 'life'}". Inspiring without being cliché. 3–4 sentences. 🔥`),
  '.fact': async (args) =>
    freeAI(`One fascinating surprising fact about "${args || 'science'}". Genuinely interesting. 2–3 sentences. Add an emoji.`),
  '.joke': async (args) =>
    freeAI(`Tell one ${args || 'witty'} joke. Setup on first line, punchline on second. Add emojis.`),
  '.quote': async (args) =>
    freeAI(`One powerful authentic quote about "${args || 'motivation'}". Include author. Format: "quote" — Author`),
  '.translate': async (args) => {
    const parts = args.split(' ');
    if (parts.length < 2) return 'Usage: *.translate* <language> <text>\nExample: *.translate* Spanish Hello, how are you?';
    const lang = parts[0];
    const text = parts.slice(1).join(' ');
    return freeAI(`Translate to ${lang}. Show ONLY the translation:\n\n${text}`);
  },
};

const CREATIVE_SET = new Set(Object.keys(CREATIVE_COMMANDS));

async function creativeCommand(sock, chatId, message) {
  try {
    const rawText =
      message.message?.conversation?.trim() ||
      message.message?.extendedTextMessage?.text?.trim() || '';
    const parts = rawText.split(/\s+/);
    const cmd = parts[0].toLowerCase();

    if (!CREATIVE_SET.has(cmd)) return;

    const args = parts.slice(1).join(' ').trim();
    const mentionedJid = message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
    const mentionName = mentionedJid ? mentionedJid.split('@')[0].slice(-4) : null;

    await sock.sendMessage(chatId, { react: { text: '✨', key: message.key } });

    const result = await CREATIVE_COMMANDS[cmd](args, mentionName);
    await sock.sendMessage(chatId, { text: result }, { quoted: message });
    await sock.sendMessage(chatId, { react: { text: '✅', key: message.key } });

  } catch (err) {
    console.error('[CREATIVE]', err.message);
    await sock.sendMessage(chatId, { text: `❌ ${err.message}` }, { quoted: message });
  }
}

creativeCommand.COMMANDS = CREATIVE_SET;
module.exports = creativeCommand;
