/**
 * LUNR BOT — Free AI Engine
 * ─────────────────────────────────────────────────────────────────────────
 * Provider priority:
 *   1. Google Gemini  — FREE 1,500 req/day  → https://aistudio.google.com
 *   2. Groq           — FREE 14,400 req/day → https://console.groq.com
 *   3. Pollinations   — FREE unlimited      → no key needed (text too!)
 *
 * Set keys in .env:
 *   GEMINI_API_KEY=your_key_here
 *   GROQ_API_KEY=your_key_here
 *
 * Bot works with ZERO keys via Pollinations fallback.
 * ─────────────────────────────────────────────────────────────────────────
 */

require('dotenv').config();
const settings = require('../settings');

// ── Per-user conversation memory (30 min idle) ─────────────────────────
const memory = new Map();

function getHistory(jid) {
  const e = memory.get(jid);
  if (!e) return [];
  if (Date.now() - e.lastAt > 30 * 60 * 1000) { memory.delete(jid); return []; }
  return e.messages;
}
function pushHistory(jid, role, content) {
  const hist = getHistory(jid);
  hist.push({ role, content });
  if (hist.length > 10) hist.splice(0, hist.length - 10);
  memory.set(jid, { messages: hist, lastAt: Date.now() });
}
function clearHistory(jid) { memory.delete(jid); }

// ── Provider 1: Google Gemini (FREE 1,500 req/day) ──────────────────────
async function callGemini(messages, systemPrompt, model = 'gemini-1.5-flash') {
  const key = process.env.GEMINI_API_KEY || settings.geminiApiKey || '';
  if (!key || key === 'YOUR_GEMINI_KEY') throw new Error('No Gemini key');

  const contents = messages.map(m => ({
    role: m.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: m.content }],
  }));

  const body = {
    contents,
    generationConfig: { maxOutputTokens: 1024, temperature: 0.7 },
  };
  if (systemPrompt) body.system_instruction = { parts: [{ text: systemPrompt }] };

  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`,
    { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }
  );
  if (!res.ok) { const t = await res.text(); throw new Error(`Gemini ${res.status}: ${t.slice(0,100)}`); }
  const data = await res.json();
  return data.candidates?.[0]?.content?.parts?.[0]?.text || '(empty response)';
}

// ── Provider 2: Groq (FREE 14,400 req/day — real LLaMA/Mistral) ─────────
async function callGroq(messages, systemPrompt, model = 'llama-3.1-8b-instant') {
  const key = process.env.GROQ_API_KEY || settings.groqApiKey || '';
  if (!key || key === 'YOUR_GROQ_KEY') throw new Error('No Groq key');

  const msgs = systemPrompt
    ? [{ role: 'system', content: systemPrompt }, ...messages]
    : messages;

  const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
    body: JSON.stringify({ model, messages: msgs, max_tokens: 1024, temperature: 0.7 }),
  });
  if (!res.ok) { const t = await res.text(); throw new Error(`Groq ${res.status}: ${t.slice(0,100)}`); }
  const data = await res.json();
  return data.choices?.[0]?.message?.content || '(empty response)';
}

// ── Provider 3: Pollinations Text (FREE unlimited — zero keys needed) ───
async function callPollinations(messages, systemPrompt) {
  const histText = messages
    .map(m => `${m.role === 'user' ? 'User' : 'Assistant'}: ${m.content}`)
    .join('\n');
  const fullPrompt = systemPrompt
    ? `${systemPrompt}\n\n${histText}\nAssistant:`
    : `${histText}\nAssistant:`;

  const res = await fetch(
    `https://text.pollinations.ai/${encodeURIComponent(fullPrompt)}`,
    { headers: { 'User-Agent': 'LUNRBot/4.0' } }
  );
  if (!res.ok) throw new Error(`Pollinations ${res.status}`);
  return (await res.text()).trim();
}

// ── Groq model map (runs the ACTUAL model, not a persona) ───────────────
const GROQ_MODELS = {
  '.llama':    'llama-3.1-8b-instant',
  '.llama3':   'llama-3.3-70b-versatile',
  '.mistral':  'mistral-saba-24b',
  '.deepseek': 'deepseek-r1-distill-llama-70b',
  '.gemma':    'gemma2-9b-it',
  '.qwen':     'qwen-qwq-32b',
};

// ── Personas ────────────────────────────────────────────────────────────
const PERSONAS = {
  '.gpt':      'You are a helpful AI assistant. Be concise and accurate.',
  '.claude':   'You are a thoughtful AI assistant. Be nuanced and honest.',
  '.ai':       'You are a smart AI assistant. Be helpful and concise.',
  '.gemini':   'You are Gemini, a helpful Google AI assistant.',
  '.llama':    'You are LLaMA by Meta. Be direct and helpful.',
  '.llama3':   'You are LLaMA 3, a powerful AI. Be thorough.',
  '.mistral':  'You are Mistral AI. Be fast, precise, and efficient.',
  '.deepseek': 'You are DeepSeek AI. Think carefully and give detailed answers.',
  '.gemma':    'You are Gemma by Google. Be helpful and concise.',
  '.qwen':     'You are Qwen AI by Alibaba. Be intelligent and helpful.',
  '.ask':      'You are a knowledgeable assistant. Answer accurately.',
  '.chat':     'You are a friendly conversational AI. Be warm and engaging.',
};

const AI_COMMANDS = new Set([
  '.gpt', '.claude', '.ai', '.gemini',
  '.llama', '.llama3', '.mistral', '.deepseek',
  '.gemma', '.qwen', '.ask', '.chat',
  '.aiforget', '.aiclear', '.forget',
]);

// ── Smart router ─────────────────────────────────────────────────────────
async function smartAI(jid, cmd, userText) {
  const history = getHistory(jid);
  const messages = [...history, { role: 'user', content: userText }];
  const system = PERSONAS[cmd] || PERSONAS['.ai'];

  // Groq-native commands (runs the actual model)
  if (GROQ_MODELS[cmd]) {
    try {
      const reply = await callGroq(messages, system, GROQ_MODELS[cmd]);
      pushHistory(jid, 'user', userText);
      pushHistory(jid, 'assistant', reply);
      return { reply, provider: GROQ_MODELS[cmd].split('-')[0] };
    } catch (e) { console.warn(`[AI] Groq failed: ${e.message}`); }
  }

  // Pollinations FIRST — always free, no key needed
  try {
    const reply = await callPollinations(messages, system);
    pushHistory(jid, 'user', userText);
    pushHistory(jid, 'assistant', reply);
    return { reply, provider: 'Pollinations' };
  } catch (e) { console.warn(`[AI] Pollinations failed: ${e.message}`); }

  // Gemini fallback
  try {
    const reply = await callGemini(messages, system);
    pushHistory(jid, 'user', userText);
    pushHistory(jid, 'assistant', reply);
    return { reply, provider: 'Gemini' };
  } catch (e) { console.warn(`[AI] Gemini failed: ${e.message}`); }

  // Groq last fallback
  const reply = await callGroq(messages, system);
  pushHistory(jid, 'user', userText);
  pushHistory(jid, 'assistant', reply);
  return { reply, provider: 'Groq/LLaMA' };
}

// ── Main handler ─────────────────────────────────────────────────────────
async function aiCommand(sock, chatId, message) {
  const jid = message.key.participant || message.key.remoteJid;
  try {
    const rawText =
      message.message?.conversation ||
      message.message?.extendedTextMessage?.text || '';
    const parts = rawText.trim().split(/\s+/);
    const cmd = parts[0].toLowerCase();

    if (cmd === '.aiforget' || cmd === '.aiclear' || cmd === '.forget') {
      clearHistory(jid);
      return sock.sendMessage(chatId, { text: '🧹 Memory cleared! Fresh start.' }, { quoted: message });
    }

    if (!AI_COMMANDS.has(cmd)) return;
    const query = parts.slice(1).join(' ').trim();

    if (!query) {
      const hasG = !!(process.env.GEMINI_API_KEY || settings.geminiApiKey || '').replace('YOUR_GEMINI_KEY','');
      const hasGr = !!(process.env.GROQ_API_KEY || settings.groqApiKey || '').replace('YOUR_GROQ_KEY','');
      return sock.sendMessage(chatId, {
        text:
          `❓ Example: *${cmd}* What are black holes?\n\n` +
          `🔌 *Active AI providers:*\n` +
          `${hasG ? '✅' : '❌'} Gemini (1,500 free req/day)\n` +
          `${hasGr ? '✅' : '❌'} Groq (14,400 free req/day)\n` +
          `✅ Pollinations (unlimited, no key)\n\n` +
          `_Use *.aiforget* to reset memory_`,
      }, { quoted: message });
    }

    await sock.sendMessage(chatId, { react: { text: '🤔', key: message.key } });
    const { reply } = await smartAI(jid, cmd, query);
    await sock.sendMessage(chatId, { text: reply }, { quoted: message });
    await sock.sendMessage(chatId, { react: { text: '✅', key: message.key } });

  } catch (err) {
    console.error('[AI]', err.message);
    await sock.sendMessage(chatId, {
      text:
        `❌ *AI failed:* ${err.message}\n\n` +
        `💡 Add free keys to *.env*:\n` +
        `• *GEMINI_API_KEY* → aistudio.google.com (free)\n` +
        `• *GROQ_API_KEY* → console.groq.com (free)`,
    }, { quoted: message });
  }
}

aiCommand.smartAI = smartAI;
aiCommand.callGemini = callGemini;
aiCommand.callGroq = callGroq;
aiCommand.callPollinations = callPollinations;
aiCommand.COMMANDS = AI_COMMANDS;
module.exports = aiCommand;
