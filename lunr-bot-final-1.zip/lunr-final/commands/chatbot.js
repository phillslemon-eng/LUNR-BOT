/**
 * Chatbot — AI auto-reply for groups/DMs
 * Uses the shared free AI engine from ai.js
 */

const fs   = require('fs');
const path = require('path');

const DATA_FILE = path.join(__dirname, '../data/userGroupData.json');

function loadData() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); }
  catch { return { groups: [], chatbot: {} }; }
}
function saveData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}
function isChatbotEnabled(chatId) {
  return !!loadData().chatbot?.[chatId];
}

// Per-chat history
const chatHistory = new Map();
function getHist(chatId) {
  if (!chatHistory.has(chatId)) chatHistory.set(chatId, []);
  return chatHistory.get(chatId);
}
function pushHist(chatId, role, content) {
  const h = getHist(chatId);
  h.push({ role, content });
  if (h.length > 20) h.splice(0, h.length - 20);
}

async function getBotReply(chatId, userText) {
  const { callGemini, callGroq, callPollinations } = require('./ai');
  const history = getHist(chatId);
  const messages = [...history, { role: 'user', content: userText }];
  const system = 'You are LUNR BOT, a friendly WhatsApp assistant. Keep replies short (1–3 sentences), conversational, and helpful. Add relevant emojis.';

  // Try each provider
  for (const fn of [
    () => callPollinations(messages, system),
    () => callGemini(messages, system),
    () => callGroq(messages, system),
  ]) {
    try {
      const reply = await fn();
      pushHist(chatId, 'user', userText);
      pushHist(chatId, 'assistant', reply);
      return reply;
    } catch { continue; }
  }
  throw new Error('All providers failed');
}

async function handleChatbotCommand(sock, chatId, message, isAdminOrOwner) {
  const text = message.message?.conversation || message.message?.extendedTextMessage?.text || '';
  const arg = text.trim().split(/\s+/)[1]?.toLowerCase();

  if (!isAdminOrOwner) {
    return sock.sendMessage(chatId, { text: '❌ Only admins/owner can toggle chatbot.' }, { quoted: message });
  }

  const data = loadData();
  if (!data.chatbot) data.chatbot = {};

  if (arg === 'on') {
    data.chatbot[chatId] = true;
    saveData(data);
    chatHistory.delete(chatId);
    return sock.sendMessage(chatId, {
      text: '🤖 *Chatbot ON* — I will reply to all messages.\nUse *.chatbot off* to disable.',
    }, { quoted: message });
  }
  if (arg === 'off') {
    delete data.chatbot[chatId];
    saveData(data);
    chatHistory.delete(chatId);
    return sock.sendMessage(chatId, { text: '🤖 *Chatbot OFF*' }, { quoted: message });
  }

  const on = isChatbotEnabled(chatId);
  return sock.sendMessage(chatId, {
    text: `🤖 Chatbot is *${on ? 'ON ✅' : 'OFF ❌'}*\n\nUse *.chatbot on* or *.chatbot off*`,
  }, { quoted: message });
}

async function handleChatbotResponse(sock, chatId, message) {
  if (!isChatbotEnabled(chatId)) return;
  const text = message.message?.conversation || message.message?.extendedTextMessage?.text || '';
  if (!text.trim()) return;
  try {
    await sock.presenceSubscribe(chatId);
    await sock.sendPresenceUpdate('composing', chatId);
    const reply = await getBotReply(chatId, text);
    await sock.sendMessage(chatId, { text: reply }, { quoted: message });
  } catch (err) {
    console.error('[CHATBOT]', err.message);
  }
}

module.exports = { handleChatbotCommand, handleChatbotResponse, isChatbotEnabled };
