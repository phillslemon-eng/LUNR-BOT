const settings = {
  packname: 'LUNR BOT',
  author: '‎',
  botName: "LUNR BOT",
  botOwner: 'Professor',
  ownerNumber: '919876543210', // Your number without +
  commandMode: "public",       // "public" or "private"
  maxStoreMessages: 20,
  storeWriteInterval: 10000,
  description: "LUNR BOT — WhatsApp Bot with Free AI",
  version: "4.0.0",
  prefix: '.',
  updateZipUrl: "https://github.com/lunr-bot/lunr-bot/archive/refs/heads/main.zip",

  // ─────────────────────────────────────────────────────────────
  //  FREE AI KEYS — add yours to .env (or paste directly here)
  // ─────────────────────────────────────────────────────────────

  // 1. Google Gemini — FREE 1,500 req/day
  //    Get key: https://aistudio.google.com  (sign in → Get API Key)
  //    Used for: .ai, .geminiimagine, .veo
  geminiApiKey: process.env.GEMINI_API_KEY || 'YOUR_GEMINI_KEY',

  // 2. Groq — FREE 14,400 req/day (runs real LLaMA, Mistral, Gemma)
  //    Get key: https://console.groq.com  (free account → API Keys)
  groqApiKey: process.env.GROQ_API_KEY || 'YOUR_GROQ_KEY',

  // 3. OpenAI — PAID, DALL-E 3 image generation
  //    Get key: https://platform.openai.com/api-keys
  //    Used for: .gptimagine
  openAiApiKey: process.env.OPENAI_API_KEY || 'YOUR_OPENAI_KEY',

  // 4. Pollinations — NO KEY NEEDED, unlimited free fallback
  //    Always active automatically.

  // ─────────────────────────────────────────────────────────────
  //  IMAGE GENERATION — Pollinations AI (FREE, no key)
  // ─────────────────────────────────────────────────────────────
  imageApiBase: 'https://image.pollinations.ai/prompt',

  // ─────────────────────────────────────────────────────────────
  //  VIDEO GENERATION — free external APIs
  // ─────────────────────────────────────────────────────────────
  videoApiBase: 'https://okatsu-rolezapiiz.vercel.app/ai/txt2video',
};

module.exports = settings;
