require('dotenv').config();

global.APIs = {
  xteam:    'https://api.xteam.xyz',
  gifted:   'https://api.giftedtech.my.id',
  siputzx:  'https://api.siputzx.my.id',
  ryzen:    'https://api.ryzendesu.vip',
  pollinations: 'https://image.pollinations.ai',
};

global.APIKeys = {
  'https://api.giftedtech.my.id': 'gifted',
};

module.exports = {
  WARN_COUNT: 3,
  APIs: global.APIs,
  APIKeys: global.APIKeys,
};
